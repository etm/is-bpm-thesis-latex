# TUM Corporate Design Book

Template for scientific theses.

Authors:
* Michael Riesch (michael.riesch@tum.de) adapted by Lukas Heidegger (lukas.heidegger@tum.de)
* Made easy to use (and replaced KOMA) by Juergen Mangler (juergen.mangler@tum.de)
* Based on the templates from https://www.tum.de/cd

Linux Users: use the Makefile (make; make clean; make force; make bib)
